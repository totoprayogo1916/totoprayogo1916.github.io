				<section id="footer" class="page-section">
					<footer id="footer-section" class="page-section pt-30 pb-30 center-xs">					
						<div class="copyright fw300 mb-sm-10"><span>&copy; Mblog v2.0 <?php echo date('Y');?> </span></div>
						<div class="caption fw300">Made with <i class="lnr lnr-heart"></i> by <a href="http://mfikri.com" target="_blank">M Fikri</a></div>
						<!-- ACROLL TO TOP-->	
						<div class="top-button"><h5>Top</h5><div class="line"></div></div>
					</footer>
				</section>